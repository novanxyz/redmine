
Rails.configuration.to_prepare do  
	require 'redmine_stats/patches/issue_patch'     
end

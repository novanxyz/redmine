require File.dirname(__FILE__) + '/../test_helper'

class PersonalProcessTaskRelationTest < ActiveSupport::TestCase
  fixtures :personal_process_task_relations

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end

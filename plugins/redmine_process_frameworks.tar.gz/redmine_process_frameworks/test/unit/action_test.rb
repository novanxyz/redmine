require File.dirname(__FILE__) + '/../test_helper'

class ActionTest < ActiveSupport::TestCase
  fixtures :actions

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end

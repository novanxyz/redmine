require File.dirname(__FILE__) + '/../test_helper'

class ActivityTest < ActiveSupport::TestCase
  fixtures :activities

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end

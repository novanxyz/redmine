module MaterialCategoriesHelper
end

class TitleOfEvent < ActiveRecord::Base
  unloadable
end
